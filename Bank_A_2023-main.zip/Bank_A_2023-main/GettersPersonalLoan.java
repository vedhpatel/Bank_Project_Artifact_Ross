public class GettersPersonalLoan {

    public GettersPersonalLoan()
    {
        double mycreditt = 0;
        double myamount = 0;
        double mymax = 0;
        double mymonth = 0;
        double myamountt = 0;
        double mymaxx = 0;
        double mymonthl = 0;
        double myamounttt = 0;
        double mymaxxx = 0;
        double mymonthll = 0;
        double myqualifyy = 0;

    }

    public Getters(double creditt,int qualifyy, double amount, double max, double month, double amountt, double maxx, double monthl, double amounttt, double maxxx, double monthll)
    {
       mycreditt = creditt;
       myamount = amount;
       mymax = max;
       mymonth = month;
       myamountt = amountt;
       mymaxx = maxx;
       mymonthl = monthl;
       myamounttt = amounttt;
       mymaxxx = maxxx;
       mymonthll = monthll;
       myqualifyy = qualifyy;

    
    }

    public double getqualifyy()
    {
        return myqualifyy;
    }
    public void setqualifyy(double qualifyy)
    {
        myqualifyy = qualifyy;
    }

    public double getamount()
    {
        return myamount;
    }

    public void setamount(double amount)
    {
        myamount = amount;
    }

    public double getcredit()
    {
        return mycreditt;
    }

    public void setcredit(double creditt)
    {
        mycreditt = creditt;
    }

    public double getmax()
    {
        return mymax;
    }

    public void setmax(double max)
    {
        mymax = max;
    }
    public double getmonth()
    {
        return mymonth;
    }
    public void setmonth(double month)
    {
        mymonth = month;
    }
    public double getamountt ()
    {
        return myamountt;
    }
    public void setamountt(double amountt)
    {
        myamountt = amountt;
    }
    public double getmaxx()
    {
        return mymaxx;
    }
    public void setmaxx(double maxx)
    {
        mymaxx = maxx;
    }
    public double getmonthl()
    {
        return mymonthl;
    }
    public void setmonthl(double monthl)
    {
        mymonthl = monthl;
    }
    public double getamounttt()
    {
        return myamounttt;
    }
    public void setamounttt(double amounttt)
    {
        myamounttt = amounttt;
    }
    public double getmaxxx()
    {
        return mymaxxx;
    }
    public void setmaxxx(double maxxx)
    {
        mymaxxx = maxxx;
    }
    public double getmonthll()
    {
        return mymonthll;
    }
    public void setmonthll(double monthll)
    {
        mymonthll = monthll;
    }


    // public void getProfile()
    // {
    //     System.out.println ("Weight: "+getWeight());
    //     System.out.println ("Height: "+getHeight());
    //     System.out.println ("Age: "+getAge());
    //     System.out.println ("Armsize: "+getArmsize());
    //     System.out.println ("Legsize: "+getLegsize());
       

    // }

    private double mycreditt;
    private double myamount;
    private double mymax;
    private double mymonth;
    private double myamountt;
    private double mymaxx;
    private double mymonthl;
    private double myamounttt;
    private double mymaxxx;
    private double mymonthll;
    private static double myqualifyy;

    








    
}

 




    