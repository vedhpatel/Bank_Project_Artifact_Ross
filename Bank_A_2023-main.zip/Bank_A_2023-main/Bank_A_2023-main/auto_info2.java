public class auto_info2
{
    public String getCreditScore()
    {
        return cscore;
    }
    public void setCreditScore(String cscore)
    {
        this.cscore = cscore;
    }
    
private String cscore;
}
