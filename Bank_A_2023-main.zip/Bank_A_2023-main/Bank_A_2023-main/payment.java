public class payment
{
    public String getPaymentDue()
    {
        return payment;
    }
    public void setPaymentDue(String payment)
    {
        this.payment = payment;
    }
    
    public String getTotalDue()
    {
        return total;
    }
    public void setTotalDue(String total)
    {
        this.total = total;
    }
    
    public String getCheckingBalance()
    {
        return checking;
    }
    public void setCheckingBalance(String checking)
    {
        this.checking = checking;
    }
    
private String payment;
private String total;
private String checking;
}
