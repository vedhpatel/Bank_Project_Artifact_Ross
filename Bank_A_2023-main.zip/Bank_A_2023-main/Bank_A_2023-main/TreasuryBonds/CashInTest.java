import java.io.IOException;

public class CashInTest {
    public static void main(String[] args) throws IOException {
       // CashIn sell = new CashIn();
       // TreasuryBondPurchase buy = new TreasuryBondPurchase();
        welcome bonds = new welcome();
        bonds.menu("ACCT");

      
    }
}
