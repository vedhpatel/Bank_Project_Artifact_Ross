public class Getters {

    public Getters()
    {
        double mycredit = 0;
        double mymoneyy = 0;
        double mytotal = 0;
        double mymonthly = 0;
        double mymoneyyy = 0;
        double mytotall = 0;
        double mymonthlyy = 0;
        double mymoneyyyy = 0;
        double mytotalll = 0;
        double mymonthlyyy = 0;

    }

    public Getters(double credit,int qualify, double moneyy, double total, double monthly, double moneyyy, double totall, double monthlyy, double moneyyyy, double totalll, double monthlyyy)
    {
       mycredit = credit;
       mymoneyy = moneyy;
       mytotal = total;
       mymonthly = monthly;
       mymoneyyy = moneyyy;
       mytotall = totall;
       mymonthlyy = monthlyy;
       mymoneyyyy = moneyyyy;
       mytotalll = totalll;
       mymonthlyyy = monthlyyy;
       myqualify = qualify;

    
    }

    public double getqualify()
    {
        return myqualify;
    }
    public void setqualify(double qualify)
    {
        myqualify = qualify;
    }

    public double getmoneyy()
    {
        return mymoneyy;
    }

    public void setmoneyy(double moneyy)
    {
        mymoneyy = moneyy;
    }

    public double getcredit()
    {
        return mycredit;
    }

    public void setcredit(double credit)
    {
        mycredit = credit;
    }

    public double gettotal()
    {
        return mytotal;
    }

    public void settotal (double total)
    {
        mytotal = total;
    }
    public double getmonthly()
    {
        return mymonthly;
    }
    public void setmonthly (double monthly)
    {
        mymonthly = monthly;
    }
    public double getmoneyyy ()
    {
        return mymoneyyy;
    }
    public void setmoneyyy (double moneyyy)
    {
        mymoneyyy = moneyyy;
    }
    public double gettotall()
    {
        return mytotall;
    }
    public void settotall (double totall)
    {
        mytotall = totall;
    }
    public double getmonthlyy()
    {
        return mymonthlyy;
    }
    public void setmonthlyy(double monthlyy)
    {
        mymonthlyy = monthlyy;
    }
    public double getmoneyyyy()
    {
        return mymoneyyyy;
    }
    public void setmoneyyyy(double moneyyyy)
    {
        mymoneyyyy = moneyyyy;
    }
    public double getotalll()
    {
        return mytotalll;
    }
    public void settotalll(double totalll)
    {
        mytotalll = totalll;
    }
    public double getmonthlyyy()
    {
        return mymonthlyyy;
    }
    public void setmonthlyyy(double monthlyyy)
    {
        mymonthlyyy = monthlyyy;
    }


    // public void getProfile()
    // {
    //     System.out.println ("Weight: "+getWeight());
    //     System.out.println ("Height: "+getHeight());
    //     System.out.println ("Age: "+getAge());
    //     System.out.println ("Armsize: "+getArmsize());
    //     System.out.println ("Legsize: "+getLegsize());
       

    // }

    private double mycredit;
    private double mymoneyy;
    private double mytotal;
    private double mymonthly;
    private double mymoneyyy;
    private double mytotall;
    private double mymonthlyy;
    private double mymoneyyyy;
    private double mytotalll;
    private double mymonthlyyy;
    private static double myqualify;

    








    
}

 




    

