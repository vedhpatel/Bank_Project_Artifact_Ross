public class HelloWorld 
{
    public static void main(String[] args) 
    {
        System.out.println("Hello World");
    System.out.println("Sample");
     System.out.println("This is a sample line that will be pulled to the Branch on November 20, 2023);
    System.out.println("This is a sample line that will be pulled to ?????");
    }
}