// AP CSA Bank Project: Treasury Interface 

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class TreasuryBondPurchase 
{
    // Offer term lengths in years
    private static final int[] TERM_LENGTHS = {20, 30}; 
    // Corresponding interest rates
    private static final double[] INTEREST_RATES = {0.045, 0.0425}; 

    public static void main(String tempid, int accounttype) throws IOException {
        Scanner scanner = new Scanner(System.in);
   
      
        // Display term lengths and corresponding interest rates
        System.out.println("Available term lengths and interest rates:");
        for (int i = 0; i < TERM_LENGTHS.length; i++) {
            System.out.println((i + 1) + ". " + TERM_LENGTHS[i] + " years at " + INTEREST_RATES[i] * 100 + "%");
        }

        // Prompt user to choose term length
        System.out.print("Enter the number corresponding to your desired term length: ");
        int choice = scanner.nextInt();
        if (choice < 1 || choice > TERM_LENGTHS.length) {
            System.out.println("Invalid choice.");
            return;
        }
        int termLength = TERM_LENGTHS[choice - 1];
        double interestRate = INTEREST_RATES[choice - 1];

        // Prompt user to enter purchase amount
        System.out.print("Enter the amount you want to purchase: ");
        double amount = scanner.nextDouble();
        if (amount < 100 || amount > 10000000) {
            System.out.println("Amount must be between $100 and $10,000,000.");
            return;
        }

        if (accounttype == 0) {
            if ( checkcash(tempid, amount, "savingsaccount.csv") == 0) {
                System.out.println("Insufficient funds.");
                return;
            }
        }

        if (accounttype == 1) {

            if ( checkcash(tempid, amount, "checkingsaccount.csv") == 0) {
                System.out.println("Insufficient funds.");
                return;
            }
        }
     
        amount = roundToNearestHundred(amount);

        // Confirm purchase
        System.out.println("You are about to purchase a treasury bond of $" + amount + " for " + termLength + " years at an interest rate of " + interestRate * 100 + "%.");
        System.out.print("Confirm purchase (yes/no): ");
        String confirmation = scanner.next();
        if (!confirmation.equalsIgnoreCase("yes")) {
            System.out.println("Purchase canceled.");
            return;
        }

        // Perform purchase and update CSV

        purchaseBond(amount, termLength, interestRate, tempid,accounttype);
        System.out.println("Purchase successful.");
    }

    private static void purchaseBond(double amount, int termLength, double interestRate, String ID, int accounttype) {
        // Update CSV
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-d");
        SimpleDateFormat Year = new SimpleDateFormat("yyyy");
        SimpleDateFormat Month = new SimpleDateFormat("MM");
  
        String month = Year.format(new Date());
        String year = Month.format(new Date());
        String currentTime = dateFormat.format(new Date());
        String csvRecord = "UserID,Term Length,Bond Interest Rate,Date and Time Purchased,Original Cost of the Bond\n";

        try {
            if (accounttype == 0 ) {
                subsavings(ID, amount, "savingsaccount.csv");
            }
            else if (accounttype == 1) {
                subsavings(ID, amount, "checkingsaccount.csv");
            }
           
        } catch (IOException e) {
                e.printStackTrace();
        }

        // Sample user ID for demonstration
        csvRecord += ID + "," + termLength + "," + interestRate + "," + currentTime + "," + amount + "," + year +"," + month +"\n"; 

        try (PrintWriter writer = new PrintWriter(new FileWriter("bonds.csv", true))) {
            writer.write(csvRecord);
        } catch (IOException e) {
            System.out.println("Failed to update CSV: " + e.getMessage());
        }
    }

     private static void subsavings(String ID, Double money, String filename) throws IOException {
        Scanner keyboard = new Scanner(System.in);

        try {
            CsvReader reader = new CsvReader(filename);

            int index = 0;
            ArrayList csvdata = new ArrayList();
            while (reader.readRecord()) {
                index++;

                String val1 = reader.get(0);
                String val2 = reader.get(1);

                if (val1.equals(ID)) {
                    val2 = (Double.parseDouble(val2) - money) + "";

                }
                csvdata.add(new String[] { val1, val2 });
            }

            reader.close();
            reader = null;

            writecsv(csvdata, filename);

        } catch (IOException e) {

            e.printStackTrace();
        }

    }

    private static int checkcash(String ID, Double money, String filename) throws IOException {
        Scanner keyboard = new Scanner(System.in);

        try {
            CsvReader reader = new CsvReader(filename);

            int index = 0;
            ArrayList csvdata = new ArrayList();
            while (reader.readRecord()) {
                index++;

                String val1 = reader.get(0);
                String val2 = reader.get(1);

                if(isNumeric(val2) == false){
                    continue;
                }
                if(Double.parseDouble(val2) < money){
                    return 0;
                    
                }

                else {
                    return 1;
                }
              

            }

            reader.close();
            reader = null;

       

        } catch (IOException e) {

            e.printStackTrace();
        }
        return 3;
    }
 public static void writecsv(ArrayList<String[]> csvdata, String filename) throws IOException {
        CsvWriter writer = new CsvWriter(filename);

        for (String[] record : csvdata) {

            writer.writeRecord(record);
            writer.flush();

        }
        writer.close();
        writer = null;
    }

    private static double roundToNearestHundred(double amount) {
        return Math.round(amount / 100) * 100;
    }

  //Source:  https://www.baeldung.com/java-check-string-number
    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;

    }
}
    
