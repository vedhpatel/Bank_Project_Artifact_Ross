import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

@SuppressWarnings("all")

public class welcome {

    public static void menu(String account) throws IOException {
        int exit = 0;
        int choice;

        Scanner keyboard = new Scanner(System.in);
        TreasuryBondPurchase buy = new TreasuryBondPurchase();
        CashIn sell = new CashIn();
        account = MainMenu.loggedInAccountId;

        System.out.println(
                "Welcome to the Federal Treasury Bond Interface! Would you like to use your checking or savings account? (0=Savings, 1=Checking)");
        choice = keyboard.nextInt();

        if (choice == 0) {

            if (searchCsvLine(0, account) == 1) {

                while (exit != 1) {

                    System.out.println("What would you like to do?"
                            + "\n 1) Buy Bonds" + "\n 2) Sell Bonds" + "\n 3) View all bonds" + "\n 4) Exit");
                    choice = keyboard.nextInt();
                    if (choice == 1) {
                        buy.main(account, choice);
                    } else if (choice == 2) {
                        sell.cashin(account, choice);
                    } else if (choice == 3) {
                        sell.printbonds(account, "bonds.csv");

                    } else if (choice == 4) {
                        System.out.println("Goodbye!");
                        break;
                    } else {
                        System.out.println("Not a valid choice");
                        continue;
                    }

                }

            } else {
                System.out.println(
                        "This account isn't registered to a savings account, please register a savings account before purchasing bonds.");
            }

        }
        else if ( choice == 1) {
            if (searchcheckingCsvLine(0, account) == 1) {

                while (exit != 1) {
    
                    System.out.println("What would you like to do?"
                            + "\n 1) Buy Bonds" + "\n 2) Sell Bonds" + "\n 3) View all bonds" + "\n 4) Exit");
                    choice = keyboard.nextInt();
                    if (choice == 1) {
                        buy.main(account, choice);
                    } else if (choice == 2) {
                        sell.cashin(account, choice);
                    } else if (choice == 3) {
                        sell.printbonds(account, "bonds.csv");
    
                    } else if (choice == 4) {
                        System.out.println("Goodbye!");
                        break;
                    } else {
                        System.out.println("Not a valid choice");
                        continue;
                    }
    
                }
    
            } else {
                System.out.println(
                        "This account isn't registered to a checking account, please register a savings account before purchasing bonds.");
            }
        }
        else {
            System.out.println("Invalid Selection");
        }

    }

    public static int searchCsvLine(int searchColumnIndex, String searchString) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("savingsaccount.csv"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            if (values[searchColumnIndex].equals(searchString)) {
                return 1;
            }

        }
        br.close();
        return 0;

    }

    public static int searchcheckingCsvLine(int searchColumnIndex, String searchString) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("savingsaccount.csv"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            if (values[searchColumnIndex].equals(searchString)) {
                return 1;
            }

        }
        br.close();
        return 0;

    }
}
